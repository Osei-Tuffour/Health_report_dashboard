# System Health Dashboard Script

##  Description
This project generates a daily system health report (disk, memory, uptime, and running services) and serves it via a web page using Docker and NGINX.

## Skills Used
- Bash scripting: `df`, `free`, `uptime`, `ps`, `service`
- Text processing: `awk`, `grep`
- Automation with `cron`
- Docker and NGINX container setup

##  Files
- `scripts/health_report.sh`: Main script to generate report
- `docs/health_report.html`: Output file served by NGINX
- `Dockerfile`: Builds the web container (optional if using `docker run` with bind mount)
- `project_readme.md`: This documentation file

##  Cron Job
Scheduled to run every 2 minutes:
