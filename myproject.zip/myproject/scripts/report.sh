#!/bin/bash
OUT=~/myproject/docs/health.html
echo "<html><body><pre>" > $OUT
echo "System Health Report - $(date)" >> $OUT
echo -e "\n">>$OUT

echo -e "\nDisk Usage:" >> $OUT
df -h >> $OUT
echo -e "\n">>$OUT

echo -e "\nMemory Usage:" >> $OUT
free -h >>$OUT
echo -e "\n">>$OUT

echo -e "\nSystem Uptime:">> $OUT
uptime >> $OUT
echo -e "\n">>$OUT

echo -e "\nRunning Services:" >> $OUT
service --status-all 2>/dev/null | grep '+' >>$OUT



echo "</pre></body></html>" >> $OUT
